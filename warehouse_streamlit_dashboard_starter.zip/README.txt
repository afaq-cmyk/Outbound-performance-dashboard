# Warehouse Performance Dashboard — Streamlit

## Included files
- `app.py` — dashboard application
- `requirements.txt` — Python packages required by Streamlit Cloud

## Run locally (Windows)
1. Install Python 3.11 or later from https://www.python.org/downloads/
2. Extract this folder to a simple location, for example `C:\warehouse_dashboard`.
3. Open Command Prompt in that folder.
4. Create a virtual environment:
   `py -m venv .venv`
5. Activate it:
   `.venv\Scripts\activate`
6. Install packages:
   `pip install -r requirements.txt`
7. Start the app:
   `streamlit run app.py`
8. A browser tab should open with the dashboard. Upload your daily `.xlsx` file.

## Publish a permanent web link with Streamlit Community Cloud
1. Sign in to GitHub or create an account at https://github.com/
2. Create a new repository, for example `warehouse-performance-dashboard`.
3. Upload `app.py` and `requirements.txt` to the repository root. Do not upload private employee spreadsheets.
4. Open https://share.streamlit.io/ and sign in with GitHub.
5. Select **Create app**, choose your repository, branch (usually `main`), and main file path `app.py`.
6. Click **Deploy**. Wait for the app to build.
7. Copy the generated `*.streamlit.app` URL. This is the link you can bookmark and share.
8. Each day, open the same link and upload the new Excel file.

## Daily usage
1. Open your Streamlit URL.
2. Upload the latest Excel workbook.
3. Select the worksheet containing the data.
4. Check the column mapping dropdowns. The app guesses common header names, but always verify them.
5. Confirm shift length (default 11 hours) and shift label (default 7:00 PM–7:00 AM).
6. Review the totals and staff table. Download processed data if needed.

## Important notes
- The dashboard processes the uploaded file during the current app session; a new upload replaces the current view.
- It does not permanently save uploaded workbooks or retain a historical day-by-day database.
- The shift-hours field is set to 11 hours by default. The app calculates `Items per Hour = Total Items / 11`.
- Target achievement is shown only if you enter a target items-per-hour value. Do not enter a target unless it matches your official team target.
- If the workbook has a different layout, use the mapping controls to select the correct columns.
- The uploaded HTML file was a static dashboard with hard-coded example staff rows; this Streamlit app reads current data from Excel instead.
- Keep employee data private. Only upload workbooks to a deployment and repository you are authorized to use. Do not commit the Excel data file to a public GitHub repository.
